# Messenger Thumbnails

Chrome extension that adds youtube thumbnails in messenger.

<img src="./screenshot.jpg" alt="extension screenshot">
